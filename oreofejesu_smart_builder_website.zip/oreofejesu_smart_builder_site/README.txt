OREOFEJESU SMART BUILDER - WEBSITE FILES

Main website page: index.html

To publish online:
1. Sign in to your hosting provider (for example, Netlify).
2. Upload/deploy this website folder or its contents as directed by the hosting provider.
3. After deployment, open the public website address provided by the host.

This package is a prototype website. It is not yet published online and does not include cloud accounts or cross-device project syncing. Check all estimates with a qualified construction professional before relying on them.
